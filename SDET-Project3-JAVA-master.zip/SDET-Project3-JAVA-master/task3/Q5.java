package sdetAssignment.task3;

import java.text.SimpleDateFormat;
import java.util.Date;

public class P5_DifferenceBetweenTwoTimePeriods {

	public static void main(String[] args) 	{		
		String dateStart = "09:29:58";
		String dateStop = "10:31:48";

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);

			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			
			System.out.print(diffHours + " : ");
			System.out.print(diffMinutes + " : ");
			System.out.print(diffSeconds + " :");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
