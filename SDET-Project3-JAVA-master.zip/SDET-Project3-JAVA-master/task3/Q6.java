package sdetAssignment.task3;

public class P6_RemoveWhiteSpace {
	
	public static void main(String[] args) 
	{		
		String text = "hi, how are you ? , where are you ? ";
		text = text.replaceAll(" ","");
		System.out.println(text);
		
	}

}

