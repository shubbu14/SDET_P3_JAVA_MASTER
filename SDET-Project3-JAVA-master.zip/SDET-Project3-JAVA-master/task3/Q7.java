package sdetAssignment.task3;

import java.text.SimpleDateFormat;
import java.util.Date;

public class P7_ConvertStringToDate {
	
	public static void main(String[] args) 
	{		
		String dateStart = "31/12/1998";
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date d1 = null;

		try {
			d1 = format.parse(dateStart);
			System.out.println(d1);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

