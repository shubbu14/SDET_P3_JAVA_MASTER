package sdetAssignment.task3;

import java.util.Scanner;

public class P4_FindFrequencyOfCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      Scanner scanner = new Scanner(System.in);
                    String str;                      
    char ch;
    int frequency = 0;
                    
                    System.out.println("Enter a sentance");
                    str = scanner.nextLine();
                    System.out.println("Enter any character from the sentance to find its frequency");
                    ch = scanner.next().charAt(0);
    for(int i = 0; i < str.length(); i++)
                    {
        if(ch == str.charAt(i))
                                {
            ++frequency;
        }
    }

    System.out.println("Frequency of " + ch + " = " + frequency);
    scanner.close();
}


	}


